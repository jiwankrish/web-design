<?php
  // silence is golden